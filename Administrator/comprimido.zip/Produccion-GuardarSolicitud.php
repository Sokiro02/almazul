<?php 
include("Lib/sesion.php");
include("Lib/display_error.php");
include("Lib/conexion.php");
include("Lib/formulas.php");
$IdUser=$_SESSION['IdUser'];
date_default_timezone_set("America/Bogota");
$TiempoActual = date('Y-m-d H:i:s');

// Consulta Usuario Responsable
$sql ="SELECT Nombres,Apellidos from T_Usuarios WHERE Id_Usuario='".$IdUser."' ";  
$result = $conexion->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) { 
$Nombres=$row['Nombres'];
$Apellidos=$row['Apellidos'];
 }
}
// Fin de la consulta 



$TxtCantidad=$_POST['TxtCantidad'];
$TxtCantidadEspera=$_POST['TxtCantidadEspera'];


if ($TxtCantidad!="") {

// Recibir Variables
	$TxtBodega=$_POST['TxtBodega'];
	$TxtTalla=$_POST['TxtTalla'];

// Consulta Nombre Talla
$sql ="SELECT Nom_Talla from T_Tallas WHERE Id_Talla='".$TxtTalla."' ";  
$result = $conexion->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) { 
$Nom_Talla=$row['Nom_Talla'];
 }
}
// Fin de la consulta 

$TxtAlmacen=$_POST['TxtAlmacen'];
$TxtRef=$_POST['TxtRef'];
$EstadoSolicitud=1;
$UltimaSolicitud=$_POST['TxtConsecutivoSolicitud'];

// Guardar Solicitud 
$sql=("INSERT INTO T_Solicitudes_Prod(Cod_Solicitud_Prod,Bodega_Id_Bodega, Cant_Solicitada, Talla_Solicitada, Tienda_Id_Tienda, Referencia_Id_Referencia, Estado_Solicitud_Prod, Fecha_Solicitud, Solicitud_Id_Usuario) VALUES ('".$UltimaSolicitud."','".$TxtBodega."','".$TxtCantidad."','".$TxtTalla."','".$TxtAlmacen."','".$TxtRef."','".$EstadoSolicitud."','".$TiempoActual."','".$IdUser."')");
//Echo($sql);
$result=$conexion->query($sql);

// Actualizar Consecutivo 
$sql=("UPDATE T_Config SET Cons_Orden_Prod='".$UltimaSolicitud."' WHERE Desarrollador='TEKSYSTEM S.A.S'");
//Echo($sql);
$result=$conexion->query($sql);

// Bucle para conocer los codigos que se requieren para el producto 
$sql ="SELECT Cod_Insumo FROM T_Insumos_Ref WHERE Referencia_Cod_Referencia='".$TxtRef."'";  
$result = $conexion->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) { 
$ListaInsumos=$ListaInsumos.$row['Cod_Insumo'].",";                  
 }
}
$CadenaInsumos=explode(",", $ListaInsumos);
//Split al Arreglo
$longitud = count($CadenaInsumos);
$min=$longitud-1;
//Recorro todos los elementos

for($i=0; $i<$min; $i++)
{
// Consulta Cantidad utilizada por Código  
$sql ="SELECT Cant_Solicitada from T_Insumos_Ref where Cod_Insumo='".$CadenaInsumos[$i]."'";  
$result = $conexion->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) { 
$CantInsumo=$row['Cant_Solicitada'];
 }
}
$TotalInsumoDescontado=$CantInsumo*$TxtCantidad;
// Fin de la consulta 

	// Movimiento en inventario de Insumos 
$TipoMovimiento="Retiro Prod.";

$sql=("INSERT INTO T_Mov_Insumos(Insumo_Cod_Insumo, Bodega_Id_Bodega_Retira, Cant_Mov, Tipo_Mov_Insumo, Solicitud_Id_Solicitud, Usuario_Id_Usuario, Fecha_Solicitud, Fecha_Realizado) VALUES('".$CadenaInsumos[$i]."','".$TxtBodega."','".$TotalInsumoDescontado."','".$TipoMovimiento."','".$UltimaSolicitud."','".$IdUser."','".$TiempoActual."','".$TiempoActual."');");
Echo($sql);
$result = $conexion->query($sql);
}

// Envio Notificaciones  
$sql ="SELECT Id_Usuario FROM T_Usuarios";  
$result = $conexion->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) { 
$ListaUser=$ListaUser.$row['Id_Usuario'].",";              
 }
}
$CadenaUser=explode(",", $ListaUser);
//Split al Arreglo
$longitud2 = count($CadenaUser);
$min2=$longitud2-1;
//Recorro todos los elementos

for($i=0; $i<$min2; $i++)
{
	$Mensaje=("Not. Producción ".$Nombres." ".$Apellidos."");
	$EstadoMensaje=1;
	$NotificaLeido=1;

		$sql=("INSERT INTO T_Notificaciones_Push(Usuario_Id_Usuario_Envia, Usuario_Id_Usuario_Recibe, Mensaje_Push, Fecha_Mensaje_Push, Estado_Mensaje_Push, Leido_Mensaje_Push) VALUES ('".$IdUser."','".$CadenaUser[$i]."','".$Mensaje."','".$TiempoActual."','".$EstadoMensaje."','".$NotificaLeido."');");
		$result = $conexion->query($sql);
}

// Primera Notificación de Producción
$PrimerComentario=utf8_decode("Confeccionar ".$TxtCantidad."Un. de la Referencia: ".$TxtRef." de la talla: ".$Nom_Talla."");

$sql=("INSERT INTO T_Comentarios_Produccion (Usuario_id_usuario, Fecha_Comentario, Comentario_Prod, Solicitud_Cod_Orden) VALUES ('".$IdUser."','".$TiempoActual."','".$PrimerComentario."','".$UltimaSolicitud."')");
$result = $conexion->query($sql);

header("location:Produccion-Solicitud.php?Mensaje=1&RefSel=".$TxtRef."");
}


//*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************

else if ($TxtCantidadEspera!="")
{


// Recibir Variables
	$TxtBodega=$_POST['TxtBodega'];
	$TxtTalla=$_POST['TxtTalla'];

// Consulta Nombre Talla
$sql ="SELECT Nom_Talla from T_Tallas WHERE Id_Talla='".$TxtTalla."' ";  
$result = $conexion->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) { 
$Nom_Talla=$row['Nom_Talla'];
 }
}
// Fin de la consulta 

$TxtAlmacen=$_POST['TxtAlmacen'];
$TxtRef=$_POST['TxtRef'];
$EstadoSolicitud=0;
$UltimaSolicitud=$_POST['TxtConsecutivoSolicitud'];


// Guardar Solicitud 
$sql=("INSERT INTO T_Solicitudes_Prod(Cod_Solicitud_Prod,Bodega_Id_Bodega, Cant_Solicitada, Talla_Solicitada, Tienda_Id_Tienda, Referencia_Id_Referencia, Estado_Solicitud_Prod, Fecha_Solicitud, Solicitud_Id_Usuario) VALUES ('".$UltimaSolicitud."','".$TxtBodega."','".$TxtCantidadEspera."','".$TxtTalla."','".$TxtAlmacen."','".$TxtRef."','".$EstadoSolicitud."','".$TiempoActual."','".$IdUser."')");
//Echo($sql);
$result=$conexion->query($sql);

// Actualizar Consecutivo 
$sql=("UPDATE T_Config SET Cons_Orden_Prod='".$UltimaSolicitud."' WHERE Desarrollador='TEKSYSTEM S.A.S'");
//Echo($sql);
$result=$conexion->query($sql);


// Primera Notificación de Producción
$PrimerComentario=utf8_decode("Verificar Insumos para confeccionar ".$TxtCantidadEspera." Un. de la Referencia: ".$TxtRef."  talla: ".$Nom_Talla."");

$sql=("INSERT INTO T_Comentarios_Produccion (Usuario_id_usuario, Fecha_Comentario, Comentario_Prod, Solicitud_Cod_Orden) VALUES ('".$IdUser."','".$TiempoActual."','".$PrimerComentario."','".$UltimaSolicitud."')");
$result = $conexion->query($sql);

header("location:Produccion-Solicitud.php?Mensaje=1&RefSel=".$TxtRef."");

}



 ?>
