<?php 
include("Lib/sesion.php");
include("Lib/display_error.php");
include("Lib/conexion.php");
include("Lib/formulas.php");
$IdUser=$_SESSION['IdUser'];
$IdRol=$_SESSION['IdRol'];
include("Lib/permisos.php");
 $MyIdTienda=$_SESSION['IdTienda'];
 $MiTienda=$_SESSION['nicktienda'];
$Aleaotorio=rand(0,9999);
//======================================================================
// Datos de Formulario Gastos
$TxtTienda=$_POST['ProyectoGasto'];
$CuentaRecibe=$_POST['CuentaRecibe'];
$TxtFecha=$_POST['TxtFecha'];
$TipoInversion=$_POST['TipoInversion'];
$TxtDetalle=$_POST['TxtDetalle'];
$Valor1=$_POST['demo1'];
$TxtMedio=$_POST['TxtMedio'];

$For_Egreso=FormatoMascara($Valor1);

date_default_timezone_set("America/Bogota");
$MarcaTemporal = date('Y-m-d H:i:s');

include("Lib/seguridad.php");
$Datos="Se guardo un egreso de la tienda: ".$TxtTienda." Detalle: ".$TxtDetalle." Valor: ".$Valor1;
$Paginas= $_SERVER['PHP_SELF'];
$seguridad = AgregarLog($IdUser,$Datos,$Paginas);


if ($TxtTienda==1) {
	$CuentaSale="2011"; // CRA NOVENA
}
elseif ($TxtTienda==2) { // BARRANQUILLA
	$CuentaSale="2012";
}
elseif ($TxtTienda==3) { // MONTERÍA
	$CuentaSale="2013";
}
elseif ($TxtTienda==4) { // CC GUATAPURÍ
	$CuentaSale="2014";
}

$target = "Images/Egresos/";
$target = $target.$Aleaotorio."-". basename( $_FILES['fotoportada']['name']);
//Writes the file to the server
//Echo($target);

if(move_uploaded_file($_FILES['fotoportada']['tmp_name'], $target))
{
  $uploadRes=true;
  
// Guardar datos

$sql=("INSERT INTO T_Mov_Cuentas(Id_Cuenta_Sale, Id_Cuenta_Entra,Fecha_Transf, Valor_Transferido,  Url_Soporte_Trans, Detalle, Por_Medio_de, Marca_Temporal,Egreso_Id_Usuario) VALUES ('".utf8_decode($CuentaSale)."','".utf8_decode($CuentaRecibe)."','".utf8_decode($TxtFecha)."','".utf8_decode($For_Egreso)."','".utf8_decode($target)."','".utf8_decode($TxtDetalle)."','".utf8_decode($TxtMedio)."','".utf8_decode($MarcaTemporal)."','".utf8_decode($IdUser)."')");
//echo($sql);
$result = $conexion->query($sql);

header("location:Egresos-tienda.php?Mensaje=1");

}
else
{
  $uploadRes=false;
  //Echo("Hola mundo");
  header("location:Egresos-tienda.php?Mensaje=2");
}

?>

