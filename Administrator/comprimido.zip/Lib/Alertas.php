<?php 
$sql ="SELECT Nom_App,Url_Web FROM T_Config WHERE Desarrollador='TEKSYSTEM S.A.S'";  
$result = $conexion->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {                
        $NomApp=$row['Nom_App'];  
        $Url_Web=$row['Url_Web'];    
 }
}
?>

<?php 
	//Validación de Permisos
$sql ="SELECT Menu_Sistema,Menu_Usuarios,Menu_Reportes FROM T_Rol_Usuario WHERE Id_Rol='".$IdRol."'";  
$result = $conexion->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {   
    	$Val_Sistema=$row['Menu_Sistema'];             
        $Val_Usuarios=$row['Menu_Usuarios'];
        $Val_Reportes=$row['Menu_Reportes'];
 }
}
//Validación de Permisos
	 ?>
	<div id="navbar" class="navbar navbar-default          ace-save-state">
			<div class="navbar-container ace-save-state" id="navbar-container">
				<button type="button" class="navbar-toggle menu-toggler pull-left" id="menu-toggler" data-target="#sidebar">
					<span class="sr-only">Toggle sidebar</span>

					<span class="icon-bar"></span>

					<span class="icon-bar"></span>

					<span class="icon-bar"></span>
				</button>

				<div class="navbar-header pull-left" >
			<?php 
				if ($IdRol==1) {
					?>
					<a href="index.php" class="navbar-brand">
						<small>
							<!-- <i class="fa fa-leaf"></i> -->
							<img id="LogoIndex" src="../Administrator/Images/Logos/icono.jpg" width="65px" height="36px">
							
						</small>
					</a>
					<?php
				}
				else if ($IdRol==2)
				{
					?>
					<a href="index-produccion.php" class="navbar-brand">
						<small>
							<!-- <i class="fa fa-leaf"></i> -->
							<img id="LogoIndex" src="../Administrator/Images/Logos/icono.jpg" width="65px" height="36px">
							
						</small>
					</a>
					<?php
				}
				else if ($IdRol==3)
				{
					?>
					<a href="index-ventas.php" class="navbar-brand">
						<small>
							<!-- <i class="fa fa-leaf"></i> -->
							<img id="LogoIndex" src="../Administrator/Images/Logos/icono.jpg" width="65px" height="36px">
							
						</small>
					</a>
					<?php

				}

			 ?>
					
				</div>
				<div class="navbar-header center" >
					
						<small>
							
							<h4 style="color:white;">
								<?php 
								 $Mitienda=$_SESSION['nicktienda'];
              						Echo($Mitienda);
								 ?>
							</h4>

							<h4 style="color:white;">
								<?php 
								 $Mitaller=$_SESSION['nicktaller'];
              						Echo($Mitaller);
								 ?>
							</h4>
						</small>
				
				</div>

				<div class="navbar-buttons navbar-header pull-right" role="navigation">
					<ul class="nav ace-nav">
						<li class="dark dropdown-modal">
							<a href="Lista-Referencias.php"> <img width="40" class="img-circle" src="../Administrator/Images/Logos/logo-camara.jpg" alt="User Avatar"></a>
						</li>
	<?php 
	$MyIdTaller=$_SESSION['IdTaller'];
		if ($MyIdTaller!="") {
	 ?>
						<li class="yellow dropdown-modal">
							<a data-toggle="dropdown" class="dropdown-toggle" href="#">
								<i class="ace-icon fa fa-money"></i>
								<span class="badge badge-grey"></span>
							</a>

							<ul class="dropdown-menu-left dropdown-navbar dropdown-menu dropdown-caret dropdown-close">
								<li class="dropdown-header">
									<i class="ace-icon fa fa-check"></i>
									Mi cuenta
								</li>

								<li class="dropdown-content">
									<ul class="dropdown-menu dropdown-navbar">

										<li>
											<a href="#">
												<div class="clearfix">
													<span class="pull-left">Ingresos</span>
													<span class="pull-right">$8.000.000</span>
												</div>

												
											</a>
										</li>
								
										<li>
											<a href="#">
												<div class="clearfix">
													<span class="pull-left">Gastos</span>
													<span class="pull-right">$3.000.000</span>
												</div>

												<div class="progress progress-mini progress-striped active">
													<div style="width:90%" class="progress-bar progress-bar-success"></div>
												</div>
											</a>
										</li>

									</ul>
								</li>
								<li class="dropdown-footer">
									<a href="Perfil.php?TAB=tabs-1">
										Ver mi cuenta
										<i class="ace-icon fa fa-arrow-right"></i>
									</a>
								</li>
							</ul>
						</li>
		<?php 
			}
		 ?>
						<li class="yellow dropdown-modal">
							<a data-toggle="dropdown" class="dropdown-toggle" href="#">
								<i class="ace-icon fa fa-tasks"></i>
								<span class="badge badge-grey"></span>
							</a>

							<ul class="dropdown-menu-left dropdown-navbar dropdown-menu dropdown-caret dropdown-close">
								<li class="dropdown-header">
									<i class="ace-icon fa fa-check"></i>
									Indicadores
								</li>

								<li class="dropdown-content">
									<ul class="dropdown-menu dropdown-navbar">

										<li>
											<a href="#">
												<div class="clearfix">
													<span class="pull-left">Efectividad</span>
													<span class="pull-right">90%</span>
												</div>

												<div class="progress progress-mini progress-striped active">
													<div style="width:90%" class="progress-bar progress-bar-danger"></div>
												</div>
											</a>
										</li>
								
										<li>
											<a href="#">
												<div class="clearfix">
													<span class="pull-left">Cumplimiento</span>
													<span class="pull-right">90%</span>
												</div>

												<div class="progress progress-mini progress-striped active">
													<div style="width:90%" class="progress-bar progress-bar-success"></div>
												</div>
											</a>
										</li>

									</ul>
								</li>
								<li class="dropdown-footer">
									<a href="Perfil.php?TAB=tabs-1">
										Ver más indicadores
										<i class="ace-icon fa fa-arrow-right"></i>
									</a>
								</li>
							</ul>
						</li>
						<li class="yellow dropdown-modal">
							<a data-toggle="dropdown" class="dropdown-toggle" href="#">
								<i class="ace-icon fa fa-tasks"></i>
								<span class="badge badge-grey"></span>
							</a>

							<ul class="dropdown-menu-left dropdown-navbar dropdown-menu dropdown-caret dropdown-close">
								<li class="dropdown-header">
									<i class="ace-icon fa fa-check"></i>
									Indicadores
								</li>

								<li class="dropdown-content">
									<ul class="dropdown-menu dropdown-navbar">

										<li>
											<a href="#">
												<div class="clearfix">
													<span class="pull-left">Efectividad</span>
													<span class="pull-right">90%</span>
												</div>

												<div class="progress progress-mini progress-striped active">
													<div style="width:90%" class="progress-bar progress-bar-danger"></div>
												</div>
											</a>
										</li>
								
										<li>
											<a href="#">
												<div class="clearfix">
													<span class="pull-left">Cumplimiento</span>
													<span class="pull-right">90%</span>
												</div>

												<div class="progress progress-mini progress-striped active">
													<div style="width:90%" class="progress-bar progress-bar-success"></div>
												</div>
											</a>
										</li>

									</ul>
								</li>
								<li class="dropdown-footer">
									<a href="Perfil.php?TAB=tabs-1">
										Ver más indicadores
										<i class="ace-icon fa fa-arrow-right"></i>
									</a>
								</li>
							</ul>
						</li>

			 <?php
// Contador de LLamadas 
$sql ="SELECT Count(Id_Llamada) as TotalLlamadas FROM T_Llamadas WHERE Llamada_Pendiente='Si'";  
$result = $conexion->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {   
      $TotalLlamadas=$row['TotalLlamadas'];
 }
}
                                     ?>

						<li class="red dropdown-modal">
							<a data-toggle="dropdown" class="dropdown-toggle" href="#">
								<i class="ace-icon fa fa-phone icon-animated-bell"></i>
								<span class="badge badge-important"><?php Echo($TotalLlamadas) ?></span>
							</a>

							<ul class="dropdown-menu-right dropdown-navbar navbar-red dropdown-menu dropdown-caret dropdown-close">
								<li class="dropdown-header">
									<i class="ace-icon fa fa-info-circle"></i>
									<?php Echo($TotalLlamadas) ?> Llamadas
								</li>
								

								<li class="dropdown-content">
									<ul class="dropdown-menu dropdown-navbar navbar-pink">
									<li><!-- start message -->
			 <?php
// Contador de LLamadas 
$sql ="SELECT date_format(Fecha_Notificacion,CONCAT(CONCAT(ELT(WEEKDAY(Fecha_Notificacion) + 1, 'Lunes', 'Martes', 'Miercoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo')),', %d - ',CONCAT(ELT(MONTH(Fecha_Notificacion), 'Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Agos', 'Sep', 'Oct', 'Nov', 'Dic')),'- %Y')) AS CreadaFecha,B.Nom_Tienda, Canal_Lead,Nombre_Lead, Celular_Lead,Fecha_Notificacion, Observacion_Admin, Estado_Llamada,Id_Llamada FROM T_Llamadas as A, T_Tiendas as B  WHERE A.Tienda_Id_Tienda=B.Id_Tienda and Llamada_Pendiente='Si' order by Id_Llamada DESC";  
$result = $conexion->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {   
      $Id_Llamada=$row['Id_Llamada'];
      $Nom_Tienda=$row['Nom_Tienda'];
      $Nombre_Lead=$row['Nombre_Lead'];
	  $Celular_Lead=$row['Celular_Lead'];
      $Fecha_Notificacion=$row['Fecha_Notificacion'];
      $Observacion_Admin=$row['Observacion_Admin'];
      $date = new DateTime($Fecha_Notificacion);
                                     ?>
                    <a href="LeadsAllb.php?LlamadaSel=<?php Echo($Id_Llamada) ?>">
                      
                      <h6>
                          <?php Echo($Nom_Tienda) ?>:Llamar al CLiente <?php Echo($Nombre_Lead); ?>
                       </h6>
                        <h6>
                         Tel: <?php Echo($Celular_Lead); ?><br>
                        <i class="fa fa-clock-o"></i> <?php Echo($CreadaFecha); ?>  <?php echo $date->format('H:i:s a');  ?><br>
                        </h6>
                        
                     
                    </a>
               <?php 
           }
       }

                ?>
                  </li>

						
									</ul>
								</li>

								<li class="dropdown-footer">
									<a href="LeadsAllb.php">
										Ver todas las llamadas
										<i class="ace-icon fa fa-arrow-right"></i>
									</a>
								</li>
							</ul>
						</li>

<?php
// Contador de LLamadas 
$sql ="SELECT Count(Id_Temporal_Sol) as TotalPrendas FROM T_Temporal_Sol WHERE Solicitud_Id_Usuari='".$IdUser."'";  
$result = $conexion->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {   
      $TotalPrendas=$row['TotalPrendas'];
 }
}
                                     ?>
						<li class="blue dropdown-modal">
							<a data-toggle="dropdown" class="dropdown-toggle" href="#">
								<i class="ace-icon fa fa-cut icon-animated-bell"></i>
								<span class="badge badge-info"><?php Echo($TotalPrendas) ?></span>
							</a>

							<ul class="dropdown-menu-right dropdown-navbar navbar-pink dropdown-menu dropdown-caret dropdown-close">
								<li class="dropdown-header">
									<i class="ace-icon fa fa-info-circle"></i>
									<?php Echo($TotalPrendas) ?> Referencias Seleccionadas
								</li>
								

								<li class="dropdown-content">
									<ul class="dropdown-menu dropdown-navbar navbar-pink">
									<li><!-- start message -->
			<?php 
$sql="SELECT C.Nom_Talla,B.Img_Referencia,Id_Temporal_Sol, Bodega_Id_Bodega, Cant_Solicitada, Talla_Solicitada, Tienda_Id_Tienda, Referencia_Id_Referencia, Fecha_Solicitud, Solicitud_Id_Usuari, Valor_Prenda, Observa_Cliente FROM T_Temporal_Sol as A, T_Referencias as B, T_Tallas as C  WHERE A.Referencia_Id_Referencia=B.Cod_Referencia and A.Talla_Solicitada=C.Id_Talla and Solicitud_Id_Usuari='".$IdUser."'";
//Echo($sql);
$result = $conexion->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) { 
$Id_Temporal_Sol=$row['Id_Temporal_Sol'];
$Nom_Talla=$row['Nom_Talla'];
$Img_Referencia=$row['Img_Referencia'];
$Bodega_Id_Bodega=$row['Bodega_Id_Bodega'];
$Cant_Solicitada=$row['Cant_Solicitada'];
$Talla_Solicitada=$row['Talla_Solicitada'];
$Tienda_Id_Tienda=$row['Tienda_Id_Tienda'];
$Referencia_Id_Referencia=$row['Referencia_Id_Referencia'];
$Fecha_Solicitud=$row['Fecha_Solicitud'];
$Solicitud_Id_Usuari=$row['Solicitud_Id_Usuari'];
$Valor_Prenda=$row['Valor_Prenda'];
$Observa_Cliente=$row['Observa_Cliente'];

$TotalPedido=$Cant_Solicitada*$Valor_Prenda;

                                     ?>
                    <a href="OrdenCliente.php">
                      <div class="pull-left">
                        <img style="margin: 10px;" src="<?php Echo($Img_Referencia) ?>" class="msg-photo" alt="User Image">
                      </div>
                      <h6>
                          <?php Echo($Referencia_Id_Referencia."-".$Nom_Talla); ?>
                        <br>
                        <small>  <?php Echo($Cant_Solicitada) ?> Und.</small>
                      </h6>
                     
                    </a>
                    <?php 
                }
            }

                     ?>
                  </li>
									</ul>
								</li>

								<li class="dropdown-footer">
									<a href="OrdenCliente.php">
										Crear Orden de Corte
										<i class="ace-icon fa fa-arrow-right"></i>
									</a>
								</li>

							</ul>
						</li>
<?php 
						$sql="SELECT count(Id_Notifica) as CuentaNot From T_Notificaciones where  Usuario_Recibe='".$IdUser."'";
$result = $conexion->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {                
        $CuentaNot=$row['CuentaNot'];
    }
}
						 ?>
						<li class="green dropdown-modal">
							<a data-toggle="dropdown" class="dropdown-toggle" href="#">
								<i class="ace-icon fa fa-bell icon-animated-vertical"></i>
								<span class="badge badge-success"><?php Echo utf8_encode($CuentaNot) ?></span>
							</a>

							<ul class="dropdown-menu-right dropdown-navbar dropdown-menu dropdown-caret dropdown-close">
								<li class="dropdown-header">
									<i class="ace-icon fa fa-bell"></i>
						
									<?php Echo utf8_encode($CuentaNot) ?> Notificaciones
								</li>

								<li class="dropdown-content">
									<ul class="dropdown-menu dropdown-navbar">
										<?php 

$sql ="SELECT Nombres,Id_Notifica,Not_Cod_Tarea, Usuario_Envia, Usuario_Recibe, Datos_Notifica, Fecha_Notifica, Estado_Notifica, Publicado, Img_Perfil FROM T_Notificaciones as A, T_Usuarios as B WHERE Usuario_Recibe='".$IdUser."' and A.Usuario_Envia=B.Id_Usuario order by Id_Notifica desc ";  
//echo ($sql);
$result = $conexion->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {                
        $Qr_Datos_Notifica=$row['Datos_Notifica'];
        $Qr_Cod=$row['Not_Cod_Tarea'];
        $Qr_Fechanot=$row['Fecha_Notifica'];
        $Qr_UserNot=$row['Nombres'];
        $Qr_imgperfil=$row['Img_Perfil'];


?>

										<li>
											<a href="Task-Timeline.php?View=<?php Echo utf8_encode($Qr_Cod); ?>&Propietario=<?php Echo utf8_encode($IdUser); ?>" class="clearfix">
												<img src="../Administrator/<?php Echo($Qr_imgperfil); ?>" class="msg-photo" />
												<span class="msg-body">
													<span class="msg-title">
														<span class="blue"><?php Echo utf8_encode($Qr_UserNot); ?></span>
														<?php Echo utf8_encode($Qr_Datos_Notifica); ?>
													</span>

													<span class="msg-time">
														<i class="ace-icon fa fa-clock-o"></i>
														<span>
															<?php 
															$date1 = new DateTime($Qr_Fechanot);
$date2 = new DateTime("now");
$diff = $date1->diff($date2);
// 38 minutes to go [number is variable]
echo ($diff->invert == 1 ) ? ' passed ' : ' Hace ';
echo ( ($diff->days * 24 ) * 60 ) + ( $diff->i ) . ' minutos';
// passed means if its negative and to go means if its positive

															 ?>

														</span><br>
														<span class="blue">Actividad:<?php Echo utf8_encode($Qr_Cod+1300); ?></span>
													</span>
												</span>
											</a>
										</li>
										<?php 
									}
								}
										 ?>
									</ul>
								</li>

								<li class="dropdown-footer">
									<a href="perfil.php?TAB=tabs-2">
										Ver todas las notificaciones
										<i class="ace-icon fa fa-arrow-right"></i>
									</a>
								</li>
							</ul>
						</li>
<?php 
						$sql="SELECT Nombres,Apellidos,Img_Perfil,Nombre_Rol From T_Usuarios as A, T_Rol_Usuario as B where A.Rol_Id_Rol=B.Id_Rol and Id_Usuario='".$IdUser."'";
$result = $conexion->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {                
        $NomUser=$row['Nombres'];
        $ApeUser=$row['Apellidos'];
        $Img_Perfil=$row['Img_Perfil'];
        $NomSesion=$NomUser." ".$ApeUser;
        $NomRol=$row['Nombre_Rol'];
        
    }
}
						 ?>
						<li class="dark dropdown-modal">
							<a data-toggle="dropdown" href="#" class="dropdown-toggle">
								<img class="nav-user-photo" src="../Administrator/<?php Echo utf8_encode($Img_Perfil); ?>" alt="Jason's Photo" />
								<span class="user-info">
									<small>Bienvenido,</small>
									<?php Echo utf8_encode($NomUser." ".$ApeUser); ?>
								</span>
								<?php 
								$TipoNot=$_GET['TipoNot'];
								   Echo(Tiponotificacion($TipoNot,$NomSesion,$Img_Perfil,"index.php"));
								 ?>
								<i class="ace-icon fa fa-caret-down"></i>
							</a>

							<ul class="user-menu dropdown-menu-right dropdown-menu dropdown-yellow dropdown-caret dropdown-close">
							<?php 
					if ($Val_Sistema==1) {
					?>
								<li>
									<a href="config.php">
										<i class="ace-icon fa fa-cog"></i>
										Configuración
									</a>
								</li>
					<?php 
				}
					 ?>

								<li>
									<a href="Perfil.php?TAB=tabs-3">
										<i class="ace-icon fa fa-user"></i>
										Perfil
									</a>
								</li>

								<li class="divider"></li>

								<li>
									<a href="../Login/Logout.php">
										<i class="ace-icon fa fa-power-off"></i>
										Salir
									</a>
								</li>
							</ul>
						</li>
					</ul>
				</div>
			</div><!-- /.navbar-container -->
		</div>