<!-- Variables -->

<?php 
define("EstadoActivo", 1)
define("EstadoInactivo", 2)
?>

