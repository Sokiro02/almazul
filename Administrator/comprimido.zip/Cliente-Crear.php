<?php 
include("Lib/sesion.php");
include("Lib/display_error.php");
include("Lib/conexion.php");
include("Lib/formulas.php");
$IdUser=$_SESSION['IdUser'];
$IdRol=$_SESSION['IdRol'];
include("Lib/seguridad.php");


$RefSel=$_GET['RefSel'];

$ForVenta=$_GET['ForVenta'];

if ($ForVenta!="") {
	// Variables de  Admin-Habitación.php

$TxtDocumento = $_POST['TxtDocumento'];
$TxtNombre = strtoupper($_POST['TxtNombre']);
$TxtApellido = strtoupper($_POST['TxtApellido']);
$TxtCiudad = strtoupper($_POST['TxtCiudad']);
$TxtCorreo = strtoupper($_POST['TxtCorreo']);
$TxtTel = strtoupper($_POST['TxtTel']);
$TxtCelular = strtoupper($_POST['TxtCelular']);
$TxtWhp = strtoupper($_POST['TxtWhp']);
$target_file="images/Perfiles/7287-User-Default.jpg";

$Datos = "Se agrego un nuevo cliente: ".$TxtNombre." ".$TxtApellido;
$EstadoTekMaster=1;

//Crear Habitación

$sql=("INSERT INTO T_Clientes (Documento_Cliente,Avatar_Cliente, Nom_Cliente, Ape_Cliente, Ciudad_Id_Ciudad, Correo_Cliente, Tel_Cliente, Cel1_Cliente, Cel2_Cliente, Tipo_Cliente) VALUES ('".utf8_decode($TxtDocumento)."','".utf8_decode($target_file)."','".utf8_decode($TxtNombre)."','".utf8_decode($TxtApellido)."','".utf8_decode($TxtCiudad)."','".utf8_decode($TxtCorreo)."','".utf8_decode($TxtTel)."','".utf8_decode($TxtCelular)."','".utf8_decode($TxtWhp)."','".utf8_decode($EstadoTekMaster)."')");
//echo($sql);
$result = $conexion->query($sql);
if ($result){
    $seguridad = AgregarLog($IdUser,$Datos,"Cliente-Crear.php");    
}


header("location:CrearVenta.php?Mensaje=4");
}
else
{
	// Variables de  Admin-Habitación.php

$TxtDocumento = $_POST['TxtDocumento'];
$TxtNombre = strtoupper($_POST['TxtNombre']);
$TxtApellido = strtoupper($_POST['TxtApellido']);
$TxtCiudad = strtoupper($_POST['TxtCiudad']);
$TxtCorreo = strtoupper($_POST['TxtCorreo']);
$TxtTel = strtoupper($_POST['TxtTel']);
$TxtCelular = strtoupper($_POST['TxtCelular']);
$TxtWhp = strtoupper($_POST['TxtWhp']);
$target_file="images/Perfiles/7287-User-Default.jpg";
$Datos = "Se agrego un nuevo cliente: ".$TxtNombre." ".$TxtApellido;
$EstadoTekMaster=1;

//Crear Habitación

$sql=("INSERT INTO T_Clientes (Documento_Cliente,Avatar_Cliente, Nom_Cliente, Ape_Cliente, Ciudad_Id_Ciudad, Correo_Cliente, Tel_Cliente, Cel1_Cliente, Cel2_Cliente, Tipo_Cliente) VALUES ('".utf8_decode($TxtDocumento)."','".utf8_decode($target_file)."','".utf8_decode($TxtNombre)."','".utf8_decode($TxtApellido)."','".utf8_decode($TxtCiudad)."','".utf8_decode($TxtCorreo)."','".utf8_decode($TxtTel)."','".utf8_decode($TxtCelular)."','".utf8_decode($TxtWhp)."','".utf8_decode($EstadoTekMaster)."')");
//echo($sql);
$result = $conexion->query($sql);
if ($result){
    $seguridad = AgregarLog($IdUser,$Datos,"Cliente-Crear.php");    
}
header("location:OrdenCliente.php?ClienteDoc=".$TxtDocumento."");
}



 ?>