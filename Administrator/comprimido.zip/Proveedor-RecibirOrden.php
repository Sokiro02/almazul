<?php 
include("Lib/sesion.php");
include("Lib/display_error.php");
include("Lib/conexion.php");
include("Lib/formulas.php");
$IdUser=$_SESSION['IdUser'];
$IdRol=$_SESSION['IdRol'];

//Actualizar Información del Insumo
// Datos extraídos de Proveedor-DetalleCompra.php

$Txt_ObservaItem = strtoupper($_POST['Txt_ObservaItem']);
$Txt_Cant_Recibida = strtoupper($_POST['Txt_Cant_Recibida']);
$Txt_IdInsumo = $_POST['Txt_IdInsumo'];
$Txt_CantSolicitada = $_POST['Txt_CantSolicitada'];
$Txt_NumeroOrden = $_POST['Txt_NumeroOrden'];
$Txt_Insumo_Cod_Insumo = $_POST['Txt_Insumo_Cod_Insumo'];
$Txt_Bodega_Id_Bodega= $_POST['Txt_Bodega_Id_Bodega'];





date_default_timezone_set("America/Bogota");
$MarcaTemporal = date('Y-m-d H:i:s');
$EstadoTek=0;

// Actualizar información en Orden de Compra
$sql=("UPDATE T_Orden_Compra_Insumos SET Cant_Recibida='".utf8_decode($Txt_Cant_Recibida)."', Observa_Compra='".$Txt_ObservaItem."', Fecha_Recibido='".$MarcaTemporal."' WHERE Id_Orden_Compra='".$Txt_IdInsumo."'");
//echo($sql);
$result = $conexion->query($sql);


// Agregar cantidades al Inventario
$TipoMov="Ingreso por Compra";

$sql=("INSERT INTO T_Mov_Insumos (Insumo_Cod_Insumo, Bodega_Id_Bodega_Recibe, Cant_Mov, Tipo_Mov_Insumo, OrdenCompra, Usuario_Id_Usuario, Fecha_Realizado) VALUES ('".utf8_decode($Txt_Insumo_Cod_Insumo)."','".utf8_decode($Txt_Bodega_Id_Bodega)."','".utf8_decode($Txt_Cant_Recibida)."','".utf8_decode($TipoMov)."','".utf8_decode($Txt_NumeroOrden)."','".utf8_decode($IdUser)."','".utf8_decode($MarcaTemporal)."')");
//echo($sql);
$result = $conexion->query($sql);

header("location:Proveedor-DetalleCompra.php?Mensaje=2&NumeroOrden=".$Txt_NumeroOrden."");


 ?>