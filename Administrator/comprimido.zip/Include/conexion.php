<?php
// Configuración conexión base de datos
// Servidor
// Nombre Base de Datos
// Password
// Usuario
$conexion = new mysqli('localhost', 'DbALLB', 'Tek@900710285', 'DbALLB');
?>