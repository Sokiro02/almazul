	<!-- <div class="footer_slider">
			<div class="swiper-container" data-autoplay="0" data-loop="1" data-speed="500" data-center="0" data-slides-per-view="responsive" data-xs-slides="4" data-sm-slides="8" data-md-slides="14" data-lg-slides="19" data-add-slides="19">
	            <div class="swiper-wrapper">
	            	<div class="swiper-slide active" data-val="0">

						<a href="gallery.html">				<img class="img-responsive img-full" src="img/f1.jpg" alt="">
	            	 </a></div>
	            	<div class="swiper-slide" data-val="1">
						<a href="gallery.html">

	            		 	 <img class="img-responsive img-full" src="img/f2.jpg" alt="">
	            	 </a></div>
	            	<div class="swiper-slide" data-val="2">
						<a href="gallery.html">

	            		 	 <img class="img-responsive img-full" src="img/f3.jpg" alt="">
	            	 </a></div>
	            	<div class="swiper-slide" data-val="3">
						<a href="gallery.html">

	            		 	 <img class="img-responsive img-full" src="img/f4.jpg" alt="">
	            	 </a></div>
	            	<div class="swiper-slide" data-val="4">
						<a href="gallery.html">

	            		 	 <img class="img-responsive img-full" src="img/f5.jpg" alt="">
	            	 </a></div>
	            	<div class="swiper-slide" data-val="5">
						<a href="gallery.html">

	            		 	 <img class="img-responsive img-full" src="img/f6.jpg" alt="">
	            	 </a></div>
	            	<div class="swiper-slide" data-val="6">
						<a href="gallery.html">

	            		 	 <img class="img-responsive img-full" src="img/f7.jpg" alt="">
	            	 </a></div>
	            	<div class="swiper-slide" data-val="7">
						<a href="gallery.html">

	            		 	 <img class="img-responsive img-full" src="img/f8.jpg" alt="">
	            	 </a></div>
	            	<div class="swiper-slide" data-val="8">
						<a href="gallery.html">

	            		 	 <img class="img-responsive img-full" src="img/f9.jpg" alt="">
	            	 </a></div>
	            	<div class="swiper-slide" data-val="9">
						<a href="gallery.html">

	            		 	 <img class="img-responsive img-full" src="img/f10.jpg" alt="">
	            	 </a></div>
	            	<div class="swiper-slide" data-val="10">
						<a href="gallery.html">

	            		 	 <img class="img-responsive img-full" src="img/f11.jpg" alt="">
	            	 </a></div>
	            	<div class="swiper-slide" data-val="11">
						<a href="gallery.html">

	            		 	 <img class="img-responsive img-full" src="img/f12.jpg" alt="">
	            	 </a></div>
	            	<div class="swiper-slide" data-val="12">
						<a href="gallery.html">

	            		 	 <img class="img-responsive img-full" src="img/f13.jpg" alt="">
	            	 </a></div>
	            	<div class="swiper-slide" data-val="13">
						<a href="gallery.html">

	            		 	 <img class="img-responsive img-full" src="img/f14.jpg" alt="">
	            	 </a></div>
	            	<div class="swiper-slide" data-val="14">
						<a href="gallery.html">

	            		 	 <img class="img-responsive img-full" src="img/f15.jpg" alt="">
	            	 </a></div>
	            	<div class="swiper-slide" data-val="15">
						<a href="gallery.html">

	            		 	 <img class="img-responsive img-full" src="img/f16.jpg" alt="">
	            	 </a></div>
	            	<div class="swiper-slide" data-val="16">
						<a href="gallery.html">

	            		 	 <img class="img-responsive img-full" src="img/f17.jpg" alt="">
	            	 </a></div>
	            	<div class="swiper-slide" data-val="17">
						<a href="gallery.html">

	            		 	 <img class="img-responsive img-full" src="img/f18.jpg" alt="">
	            	 </a></div>
	            	<div class="swiper-slide" data-val="18">
						<a href="gallery.html">

	            		 	 <img class="img-responsive img-full" src="img/f19.jpg" alt="">
	            	 </a></div>
	            	<div class="swiper-slide" data-val="19">
						<a href="gallery.html">

	            		 	 <img class="img-responsive img-full" src="img/f1.jpg" alt="">
	            	 </a></div>
	            	<div class="swiper-slide" data-val="20">
						<a href="gallery.html">

	            		 	 <img class="img-responsive img-full" src="img/f2.jpg" alt="">
	            	 </a></div>
	            	<div class="swiper-slide" data-val="21">
						<a href="gallery.html">

	            		 	 <img class="img-responsive img-full" src="img/f3.jpg" alt="">
	            	 </a></div>
	            	<div class="swiper-slide" data-val="22">
						<a href="gallery.html">

	            		 	 <img class="img-responsive img-full" src="img/f4.jpg" alt="">
	            	 </a></div>
	            	<div class="swiper-slide" data-val="23">
						<a href="gallery.html">

	            		 	 <img class="img-responsive img-full" src="img/f5.jpg" alt="">
	            	 </a></div>
	            </div>
	            <div class="pagination hidden"></div>
	        </div>
        </div>	 -->
		<!-- <div class="footer-main">
			<div class="container-fluid custom-container">
				<div class="row">	
					<div class="col-md-3 col-xl-4">
						<div class="footer-block">
							<h1 class="footer-title">About Us</h1>
							<p>Vestibulum tincidunt, augue fermentum accumsan viverra, eros dui rutrum libero, nec imperdiet felis sem in augue luctus <a href="blog-detail-2.html">diam a porta</a> iaculis. Vivamus sit amet fermentum nisl. Duis id <a href="blog-detail-2.html">massa id purus</a> tristique varius a sit amet est. Fusce dolor libero, efficitur et lobortis at, faucibus nec nunc.</p>
							<ul class="soc_buttons">
								<li><a href=""><i class="fa fa-facebook"></i></a></li>
								<li><a href=""><i class="fa fa-twitter"></i></a></li>
								<li><a href=""><i class="fa fa-google-plus"></i></a></li>
								<li><a href=""><i class="fa fa-pinterest-p"></i></a></li>
								<li><a href=""><i class="fa fa-instagram"></i></a></li>
								<li><a href=""><i class="fa fa-linkedin"></i></a></li>
							</ul>
						</div>
					</div>
					<div class="col-md-3 col-xl-2">
						<div class="footer-block">
							<h1 class="footer-title">Some Links</h1>
							<div class="row footer-list-footer">
								<div class="col-md-6">
								<ul class="link-list">
									<li><a href="about-us.html">About Us</a></li>
									<li><a href="contact-us.html">Help</a></li>
									<li><a href="contact-us.html">Contacts</a></li>
									<li><a href="activity.html">Job</a></li>
									<li><a href="activity.html">Projets</a></li>
								</ul></div>
								<div class="col-md-6">
								<ul class="link-list">
									<li><a href="activity.html">New Works</a></li>
									<li><a href="author.html">Popular Authors</a></li>
									<li><a href="author.html">New Authors</a></li>
									<li><a href="people.html">Career</a></li>
									<li><a href="faq">FAQ</a></li>
								</ul>
								</div>
							</div>
						</div>
					</div>				
					<div class="col-md-3 galerry">
						<div class="footer-block">					
							<h1 class="footer-title">Recent Works</h1>
							<a href="blog-detail-2.html"><img src="img/g1.jpg" alt=""></a>
							<a href="blog-detail-2.html"><img src="img/g2.jpg" alt=""></a>
							<a href="blog-detail-2.html"><img src="img/g3.jpg" alt=""></a>
							<a href="blog-detail-2.html"><img src="img/g4.jpg" alt=""></a>
							<a href="blog-detail-2.html"><img src="img/g5.jpg" alt=""></a>
							<a href="blog-detail-2.html"><img src="img/g6.jpg" alt=""></a>
							<a href="blog-detail-2.html"><img src="img/g7.jpg" alt=""></a>
							<a href="blog-detail-2.html"><img src="img/g8.jpg" alt=""></a>
							<a href="blog-detail-2.html"><img src="img/g9.jpg" alt=""></a>
							<a href="blog-detail-2.html"><img src="img/g10.jpg" alt=""></a>
							<a href="blog-detail-2.html"><img src="img/g11.jpg" alt=""></a>
							<a href="blog-detail-2.html"><img src="img/g12.jpg" alt=""></a>
						</div>
					</div>
					<div class="col-md-3">
						<div class="footer-block">
							<h1 class="footer-title">Subscribe On Our News</h1>
							<form action="./" class="subscribe-form">
								<input type="text" placeholder="Yout Name" required>
								<div class="submit-block">
									<i class="fa fa-envelope-o"></i>
									<input type="submit" value="">
								</div>
							</form>
							<div class="soc-activity">
								<div class="soc_ico_triangle">
									<i class="fa fa-twitter"></i>
								</div>
								<div class="message-soc">
									<div class="date">16h ago</div>
									<a href="blog-detail-2.html" class="account">@faq</a> vestibulum accumsan est <a href="blog-detail-2.html" class="heshtag">blog-detail-2.htmlmalesuada</a> sem auctor, eu aliquet nisi ornare leo sit amet varius egestas.
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div> -->
		<div class="footer-bottom">
			<div class="container-fluid custom-container">
				<div class="col-md-12 footer-end clearfix">
					<div class="left">
						<span class="copy">© 2017. Todos los Derechos Reservados. <span class="white"><a href="www.diconingenieria.com"> DICON INGENIERIA INVERSIONES S.A.S</a></span></span>
						<span class="created">Desarrollado por: <span class="white"><a href="www.teksystem.co"> TEKSYSTEM S.A.S</a></span></span>
					</div>
					<div class="right">
						<a href="nosotros.php" class="btn color-7 size-2 hover-9">¿Quiénes Somos?</a>
						<a href="preguntas.php" class="btn color-7 size-2 hover-9">Ayuda</a>
						<a class="btn color-7 size-2 hover-9">Políticas de Privacidad</a>
					</div>
				</div>			
			</div>
		</div>		