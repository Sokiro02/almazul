<?php 

include("Lib/sesion.php");
error_reporting(E_ALL ^ E_NOTICE);
ini_set("display_errors", 1); 
include("Lib/display_error.php");
include("Lib/conexion.php");
include("Lib/formulas.php");
$IdUser=$_SESSION['IdUser'];
//RECOGER INFORMACIÒN DE RECEPCION_MERCANCIA.PHP
if(isset($_POST['submit'])){
    $status = "RECIBIDO"; //STATUS DEL DESPACHO Y DE LAS REFERENCIAS EN LAS DIFERENTES TABLAS t_temporal_inventario,t_temporal_inventario_despacho
    $id_despacho = $_POST['ID'];
    $observaciones = $_POST['comentarios'];
    $TiempoActual = date('Y-m-d H:i:s');
    $idtienda = $_POST['ID_TIENDA'];
    $total_despacho = $_POST['TOTAL'];
    $error_guardar = 0;    
    
    /*3) TRASPASAR LAS REFERENCIAS A LA TABLA T_INVENTARIO_REF*/
    //SELECCIONAR TODOS LAS REFERENCIAS DEL DESPACHO PARA TRASPASAR AL INVENTARIO
    $sql="SELECT * FROM t_temporal_inventario WHERE id_despacho='".$id_despacho."'";
    $result= $conexion->query($sql) or die('Error en :'.$sql.mysqli_error($conexion));
    if($result->num_rows>0){
    	while ($fil = $result->fetch_assoc()) {
    	   $id_ref=$fil['id_ref'];
           $cod_ref_completo=$fil['cod_ref'];
           $cod_ref = explode("-", $cod_ref_completo);
           $cod_referencia=$cod_ref[0];
           $cantidad=$fil['cantidad'];
           $talla_id=$fil['talla_id'];
           $idtienda=$fil['id_tienda'];
           $cliente = $fil['cliente'];
           $cliente=strtoupper($cliente);
           $Tipo_Mov_Inv="DESPACHO";
           //INSERTAR DATOS A LA TABLA T_INVENTARIO_REF
           $sql3="INSERT INTO t_inventario_ref(Tienda_Id_Tienda,Inv_Ref,Talla_Id_Talla,Ref_Completa,Cantidad_Inv,
           Fecha_Ingreso,Tipo_Mov_Inv,Responsable_Id_Usuario,Fecha_Registro_ALLB,cliente) 
           VALUES 
           ('".$idtienda."','".$cod_referencia."','".$talla_id."','".$cod_ref_completo."','".$cantidad."',
           '".$TiempoActual."','".$Tipo_Mov_Inv."','".$IdUser."','".$TiempoActual."','".$cliente."')";
           $EJECUTAR=$conexion->query($sql3) or die('Error en :'.$sql3.mysqli_error($conexion));
           
           if ($cliente<>'SI'){
                //AGREGAR O ACTUALIZAR DATOS DE LA TABLA DEL INVENTARIO REAL           
                $sql1 ="SELECT Id_Tienda,Referencia_Completa FROM t_inventario WHERE Id_Tienda='".$idtienda."' and Referencia_Completa='".$cod_ref_completo."'" ;
                $resultados = $conexion->query($sql1) or die (mysqli_error($conexion));
                if ($resultados->num_rows>0){ //SI LA REFERENCIA YA ESTA CARGADA EN EL INVENTARIO.
                    $SqlActualizar ="UPDATE t_inventario SET Cantidad=Cantidad+'".$cantidad."' WHERE Id_Tienda='".$idtienda."' and Referencia_Completa='".$cod_ref_completo."'"; //ACTUALIZAMOS EL INVENTARIO
                    $ResultActualizar = $conexion->query($SqlActualizar)or die (mysqli_error($conexion));
                }else{ //SI LA REFERENCIA NO ESTA CARGADA EN EL INVENTARIO
                    $SqlAgregar ="INSERT INTO t_inventario(Id,Id_Tienda,Referencia,Referencia_Completa,Cantidad,Id_Talla) VALUES ('','".$idtienda."','".$cod_referencia."','".$cod_ref_completo."','".$cantidad."','".$talla_id."')"; //AGREGAMOS LA NUEVA REFERENCIA AL INVENTARIO
                    $ResultInsertar = $conexion->query($SqlAgregar);
                }
           }
           if (!$EJECUTAR){
                $error_guardar = 1;
                header("location:tiendas_recepcion.php?Mensaje=61");
           }
        }
     }    
    
    
    /* REALIZA LA SUMA DEL INVENTARIO RECIBIDO*/
    $consulta_inventario ="SELECT sum(valor_total) as suma FROM t_temporal_inventario WHERE id_despacho='".$id_despacho."'";
    $resultados = $conexion->query($consulta_inventario) or die('Error:'.$consulta_inventario." ".mysqli_error($conexion));
    if($resultados->num_rows>0){
    	while ($row = $resultados->fetch_assoc()) {
    	   $suma = $row['suma'];
        }
     }    
    
    
    /*1) ACTUALIZAR LA TABLA DE T_TEMPORAL INVENTARIO*/
    $ActualizarT_Temporal_Inventario="UPDATE t_temporal_inventario SET status_recibido='".$status."'
    WHERE
     status_recibido='ENVIADO' and id_despacho='".$id_despacho."'";
    $ejecutar2=$conexion->query($ActualizarT_Temporal_Inventario) or die('Error:'.$ActualizarT_Temporal_Inventario." ".mysqli_error($conexion));
    if (!$ejecutar2){
        $error_guardar = 1;
    }
    
    /*2) ACTUALIZAR LA TABLA DE t_temporal_inventario_despachos*/
    $ActualizarT_Temporal_Inventario_despacho="UPDATE t_temporal_inventario_despachos SET status_despacho='".$status."',
    fecha_recepcion='".$TiempoActual."',id_user_recepcion='".$IdUser."',total_despacho='".$suma."',observaciones='".$observaciones."'
    WHERE
    status_despacho='DESPACHADO' and id_despacho='".$id_despacho."'";
    $ejecutar3=$conexion->query($ActualizarT_Temporal_Inventario_despacho) or die('Error:'.$ActualizarT_Temporal_Inventario_despacho." ".mysqli_error($conexion));
    if (!$ejecutar3){
        $error_guardar = 1;
    }
    
    if ($error_guardar==0){
        header("location:tiendas_recepcion.php?Mensaje=63");
    }
        
}else{
    header("location:tiendas_recepcion.php?Mensaje=60");
}
?>