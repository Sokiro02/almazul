<?php 
include("Lib/sesion.php");
include("Lib/display_error.php");
include("Lib/conexion.php");
include("Lib/formulas.php");
$IdUser=$_SESSION['IdUser'];
$IdRol=$_SESSION['IdRol'];
include("Lib/seguridad.php");


// Variables de  Bodegas.php
$UpTxtDocumento = strtoupper($_POST['UpTxtDocumento']);
$UpTxtNombres = strtoupper($_POST['UpTxtNombres']);

$UpTxtApellidos = strtoupper($_POST['UpTxtApellidos']);
$UpTxtCelular = strtoupper($_POST['UpTxtCelular']);
$UpTxtCiudad = strtoupper($_POST['UpTxtCiudad']);
$UpTxtCorreo = strtoupper($_POST['UpTxtCorreo']);
$TxtEditCliente=$_POST['TxtEditCliente'];

$Datos = "Se actualizo el cliente: ".$UpTxtDocumento." ".$UpTxtNombres." ".$UpTxtApellidos;
$EstadoTekMaster=1;

//Actualizar Información de Bodegas
// Datos extraídos de Bodegas.php

$sql=("UPDATE T_Clientes SET Documento_Cliente='".utf8_decode($UpTxtDocumento)."', Nom_Cliente='".utf8_encode($UpTxtNombres)."', Ape_Cliente='".utf8_decode($UpTxtApellidos)."', Ciudad_Id_Ciudad='".utf8_decode($UpTxtCiudad)."', Cel1_Cliente='".utf8_decode($UpTxtCelular)."'  WHERE Id_Cliente='".$TxtEditCliente."'");
//echo($sql);
$result = $conexion->query($sql);
if ($result){
    $seguridad = AgregarLog($IdUser,$Datos,"Clientes-ActualizarCliente.php");    
}

header("location:Clientes.php?Mensaje=2");


 ?>