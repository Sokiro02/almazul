<?php 
include("Lib/sesion.php");
include("Lib/display_error.php");
include("Lib/conexion.php");
include("Lib/formulas.php");

$IdUser=$_SESSION['IdUser'];
date_default_timezone_set("America/Bogota");
$TiempoActual = date('Y-m-d H:i:s');
// Variables de  OrdenCliente.php 

$TxtConsecutivoFactura=$_POST['TxtConsecutivo'];
$TxtConsecutivoPedido=$_POST['TxtConsecutivoPedido'];
$TxtConsecutivoCaja=$_POST['TxtConsecutivoCaja'];
$TxtTienda=$_POST['TxtTienda'];
$TxtCliente=$_POST['TxtClienteSel'];
$TxtSumaPedido=$_POST['TxtSumaPedido'];
$TxtTotalsinIva=$_POST['TxtTotalsinIva'];
$TxtTotalIva=$_POST['TxtTotalIva'];
$SumaPagos=$_POST['SumaAbono'];
$SumaAnticipos=$_POST['SumaAnticipos'];
$EstadoIngreso=1; // Confirmado
$EstadoTekMaster=1;
$EstadoIngreso=1; // Confirmado

if ($TxtSumaPedido==0) {
	header("location:CrearCliente.php?ClientePedido=".$TxtCliente."&Mensaje=22");
}
else
{

// Actualización del Pedido Entregado
$PedidoEntregado=10; // Lista de Espera
$sql=("UPDATE T_Pedido SET Estado_Pedido='".$PedidoEntregado."',Fecha_EntregaCliente='".$TiempoActual."',Factura_Num_Factura='".$TxtConsecutivoFactura."' WHERE Cod_Pedido='".$TxtConsecutivoPedido."'");
echo($sql);
$result = $conexion->query($sql);



// Registro pago pendiente.		
foreach($_POST['TxtIdPago'] as $index => $nf) {

    $Codigo=$nf;
    $Monto=($_POST['TxtValorPago'][$index]);
    $TipoPago=($_POST['TxtTiporPago'][$index]);
    $TxtVoucherPago=($_POST['TxtVoucherPago'][$index]);
    $ConceptoVenta=utf8_decode("ANTICIPO A PEDIDO  PDC".$TxtConsecutivoPedido."");
    
 $sql=("INSERT INTO T_Ingresos(Cod_Recibo_Caja, Pedido_Id_Pedido,Factura_Cod_Factura,Fecha_Ingreso, Ingreso_Id_Usuario, Medio_Pago, Num_Transaccion, Valor_Ingreso, Cliente_Id_Cliente, Tienda_Id_Tienda, Concepto_Ingreso,Estado_Ingreso) VALUES ('".$TxtConsecutivoCaja."','".$TxtConsecutivoPedido."','".$TxtConsecutivoFactura."','".utf8_decode($TiempoActual)."','".utf8_decode($IdUser)."','".utf8_decode($TipoPago)."','".utf8_decode($TxtVoucherPago)."','".utf8_decode($Monto)."','".utf8_decode($TxtCliente)."','".utf8_decode($TxtTienda)."','".utf8_decode($ConceptoVenta)."','".$EstadoIngreso."');");

echo($sql);
$result = $conexion->query($sql);

		}
// Actualizar el consecutivo de Recibos de Caja
 $sql=("UPDATE T_Config_Tienda SET Consecutivo_ReciboCaja='".$TxtConsecutivoCaja."' WHERE Tienda_Id_Tienda='".$TxtTienda."';");
echo($sql);
$result = $conexion->query($sql);

// Guardar Factura

$EstadoFactura=1; // Confirmada
$TxtTipoVenta=1; // Contado

$sql=("INSERT INTO T_Facturas (Fecha_Factura, Num_Factura, Cliente_Id_Cliente, Subtotal_Factura, Iva_Factura, Total_Factura, Estado_Factura,Factura_Paga, Marca_Temporal, Usuario_Vendedor, Tienda_Id_Tienda) VALUES ('".utf8_decode($TiempoActual)."','".utf8_decode($TxtConsecutivoFactura)."','".utf8_decode($TxtCliente)."','".utf8_decode($TxtTotalsinIva)."','".utf8_decode($TxtTotalIva)."','".utf8_decode($TxtSumaPedido)."','".utf8_decode($EstadoFactura)."','".utf8_decode($TxtTipoVenta)."','".utf8_decode($TiempoActual)."','".utf8_decode($IdUser)."','".utf8_decode($TxtTienda)."')");
echo($sql);
$result = $conexion->query($sql);

// Actualización del Consecutivo de Facturas
 $sql=("UPDATE T_Config_Tienda SET Consecutivo_Factura='".$TxtConsecutivoFactura."' WHERE Tienda_Id_Tienda='".$TxtTienda."';");
echo($sql);
$result = $conexion->query($sql);



// Actualización de las solicitudes de producción
$EstadoEntrega=10; // Lista de Espera

$sql=("UPDATE T_Temporal_Sol SET Estado_Solicitud_Cliente='".$EstadoEntrega."', Fecha_EntregaCliente='".$TiempoActual."', Solicitud_Facturada='1',Factura_Num_Factura='".$TxtConsecutivoFactura."' WHERE Pedido_Id_Pedido='".$TxtConsecutivoPedido."'");
echo($sql);
$result = $conexion->query($sql);




// Registro de Ventas

foreach ($_POST['TxtCadIdVenta'] as $IdVenta => $Iv) {
  $VentaId=$Iv;
  $TxtRefVenta=($_POST['TxtRefVenta'][$IdVenta]);
  $TxtTallaVenta=($_POST['TxtTallaVenta'][$IdVenta]);
  $TxtRefCompletaVenta=($_POST['TxtRefCompletaVenta'][$IdVenta]);
  $TxtCantVenta=($_POST['TxtCantVenta'][$IdVenta]);
  $TxtValorVenta=($_POST['TxtValorVenta'][$IdVenta]);
  $TxtValorFinal=($_POST['TxtValorFinal'][$IdVenta]);


 $sql=("INSERT INTO T_Ventas( Cant_Solicitada, Talla_Solicitada, Tienda_Id_Tienda, Referencia_Id_Referencia, Ref_Vendida, Fecha_Solicitud, Vendedor_Id_Usuario, Valor_Prenda, Valor_Final,Cliente_Id_Cliente, Factura_Id_Factura) VALUES ('".utf8_decode($TxtCantVenta)."','".utf8_decode($TxtTallaVenta)."','".utf8_decode($TxtTienda)."','".utf8_decode($TxtRefVenta)."','".utf8_decode($TxtRefCompletaVenta)."','".utf8_decode($TiempoActual)."','".utf8_decode($IdUser)."','".utf8_decode($TxtValorVenta)."','".utf8_decode($TxtValorFinal)."','".utf8_decode($TxtCliente)."','".utf8_decode($TxtConsecutivoFactura)."')");
echo($sql);
$result = $conexion->query($sql);

}

// Actualización de Factura a los anticipos

$sql=("UPDATE T_Ingresos SET Factura_Cod_Factura='".$TxtConsecutivoFactura."' Pedido_Id_Pedido='".$TxtConsecutivoPedido."'");
echo($sql);
$result = $conexion->query($sql);

$sql=("DELETE FROM Ingreso_Temporal_Usuario WHERE Usuario_Ingreso='".$IdUser."' and Pago_De='Orden';");
echo($sql);
$result = $conexion->query($sql);

header("location:PedidosEntregados.php?Mensaje=333&Factura=".$TxtConsecutivoFactura."");
}

 ?>