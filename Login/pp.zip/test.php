<?php 

$username = $_POST['txtNombre'];
$password = $_POST['TxtPass'];

echo($username);


 ?>